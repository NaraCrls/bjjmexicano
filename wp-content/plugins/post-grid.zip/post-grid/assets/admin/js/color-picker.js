jQuery(document).ready(function($){	

	$('.post-grid-color').wpColorPicker();

	});